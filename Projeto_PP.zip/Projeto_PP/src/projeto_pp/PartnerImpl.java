/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_pp;
import cbl.participants.Contact;
import cbl.participants.Instituition;
import cbl.participants.Partner;
/**
 *
 * @author Leonardo
 */
public class PartnerImpl extends ParticipantImpl implements Partner {
    private String vat;
    
    private String website;

    public PartnerImpl(String vat, String website, String name, String email, Contact contact, Instituition institution) {
        super(name, email, contact, institution);
        this.vat = vat;
        this.website = website;
    }


    @Override
    public String getVat() {
        return this.vat; 
    }

    @Override
    public String getWebsite() {
        return this.website;
    }
    
}
