/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projeto_pp;
import cbl.participants.Contact;
import cbl.participants.Instituition;
import cbl.participants.Student;
/**
 *
 * @author Leonardo
 */
public class StudentImpl extends ParticipantImpl implements Student{
    private int number;

    public StudentImpl(int number, String name, String email, Contact contact, Instituition institution) {
        super(name, email, contact, institution);
        this.number = number;
    }
    
    @Override
    public int getNumber() {
        return this.number;
    }
        
}
