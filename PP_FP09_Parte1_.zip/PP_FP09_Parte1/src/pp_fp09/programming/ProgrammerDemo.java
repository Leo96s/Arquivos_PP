/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pp_fp09.programming;

import Enumerations.HabilitacoesLiterarias;
import Enumerations.TipContrato;

/**
 *
 * @author Leonardo
 */
public class ProgrammerDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Administrative admin = new Administrative("ABC", TipContrato.INTEGRAL, HabilitacoesLiterarias.LICENCIATURA, "22-03-1982", "23-07-1982",
        "David", "12-03-1977", "rua da cobica", 123456789, 1234, 721);
        
        System.out.println(admin.toString());
    }
    
}
