package grupoiii;
import grupoiii.enums.CatType;

public interface Cathelp {
    

    public void setCatType(CatType catType);
}
