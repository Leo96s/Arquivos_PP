package grupoiii;
import grupoiii.enums.SizeType;
public interface Doghelp {
    
    public void setSizeType(SizeType sizeType);

}